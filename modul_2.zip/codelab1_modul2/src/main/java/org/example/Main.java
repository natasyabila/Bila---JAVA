package org.example;
import java.util.Scanner;

class Mahasiswa {
    private String nama;
    private String nim;
    private String jurusan;

    public Mahasiswa(String nama, String nim, String jurusan) {
        this.nama = nama;
        setNim(nim);
        this.jurusan = jurusan;
    }

    public void setNim(String nim) {
        // Memastikan panjang nim tidak kurang dan tidak lebih dari 15 angka
        if (nim.length() == 15) {
            this.nim = nim;
        } else {
            System.out.println("Panjang NIM harus 15 angka.");
            System.exit(0); // Keluar dari program jika panjang NIM tidak sesuai
        }
    }

    public void tampilDataMahasiswa() {
        System.out.println("Nama: " + nama);
        System.out.println("NIM: " + nim);
        System.out.println("Jurusan: " + jurusan);
    }

    public static void tampilUniversitas() {
        System.out.println("Selamat datang di Universitas ABC");
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Mahasiswa mahasiswa = null; // Declare outside the loop

        int pilihan = 0;

        while (pilihan != 3) {
            System.out.println("\nMenu");
            System.out.println("1. Tambah Data Mahasiswa");
            System.out.println("2. Tampilkan Data Mahasiswa");
            System.out.println("3. Keluar");

            System.out.println("Pilihan Anda:  ");
            pilihan = scanner.nextInt();
            scanner.nextLine();

            switch (pilihan) {
                case 1:
                    System.out.println("Masukkan data mahasiswa:");
                    System.out.print("Nama: ");
                    String nama = scanner.nextLine();

                    System.out.print("NIM: ");
                    String nim = scanner.nextLine();

                    System.out.print("Jurusan: ");
                    String jurusan = scanner.nextLine();

                    mahasiswa = new Mahasiswa(nama, nim, jurusan); // Assign the object here

                    System.out.println("Data Berhasil ditambahkan");
                    break;

                case 2:
                    if (mahasiswa != null) {
                        System.out.println("\nDetail Mahasiswa:");
                        mahasiswa.tampilDataMahasiswa();
                    } else {
                        System.out.println("Data mahasiswa belum ditambahkan. Silakan pilih opsi 1 terlebih dahulu.");
                    }
                    break;

                case 3:
                    System.out.println("Adios");
                    break;

                default:
                    System.out.println("Pilihan tidak valid. Silahkan kembali");
                    break;
            }
        }

        scanner.close();
    }
}
